<?php

$config['Role'] = array(
	'admin' => '1',
	'user' => '2',
);

$config['Config'] = array(
	'pageName' => 'CakeFest App',
	'adminEmail' => '', // See configs_private.php
	'adminName' => 'Mark',
	'rememberMe' => false,
);

$config['Asset'] = array(
	'js' => 'buffer'
);

/* Please provide the following using the configs_private.php which is not under version control */

$config['Mail'] = array(
	'smtpHost' => '',
	'smtpUsername' => '',
	'smtpPassword' => ''
);
