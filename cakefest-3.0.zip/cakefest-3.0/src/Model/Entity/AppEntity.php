<?php
namespace App\Model\Entity;

use Tools\Model\Entity\Entity;

class AppEntity extends Entity {
}