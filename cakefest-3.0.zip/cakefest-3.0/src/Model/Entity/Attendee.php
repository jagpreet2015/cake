<?php
namespace App\Model\Entity;

use App\Model\Entity\AppEntity;

class Attendee extends AppEntity {

}
