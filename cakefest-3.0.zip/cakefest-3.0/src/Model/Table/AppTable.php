<?php
namespace App\Model\Table;

use Tools\Model\Table\Table;

class AppTable extends Table {
}