<?php

namespace App\View\Helper;

use Cake\View\Helper;

class AppHelper extends Helper {
}
